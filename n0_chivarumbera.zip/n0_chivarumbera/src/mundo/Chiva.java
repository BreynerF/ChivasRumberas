package mundo;

public class Chiva 
{
	//------------------------------------
		// Atributos
		//------------------------------------
		private String nombre;
		private int capacidad;
		private int cantidadSillas;
		private int precioHora;
		
		//------------------------------------
		// Constructor
		//------------------------------------
		
		public Chiva( String pNombre, int pCapacidad, int pCantidadSillas, int pPrecioHora )
		{
			nombre = pNombre;
			capacidad = pCapacidad;
			cantidadSillas = pCantidadSillas;
			precioHora = pPrecioHora;
		}
		
		
		//------------------------------------
		// Metodos
		//------------------------------------
		
		public String getNombre( )
		{
			return nombre;
		}
		
		public int getCapacidad( )
		{
			return capacidad;
		}
		
		public int getCantidadSillas( )
		{
			return cantidadSillas;
		}
		
		public int getPrecioHora( )
		{
			return precioHora;
		}
		
		public void setNombre(  String pNombre )
		{
			nombre = pNombre;
		}
		
		public void setCapacidad( int pCapacidad )
		{
			capacidad = pCapacidad;
		}
		
		public void setCantidadSillas( int pCantidadSillas )
		{
			cantidadSillas = pCantidadSillas;
		}
		
		public void setPrecioHora( int pPrecioHora )
		{
			precioHora = pPrecioHora;
		}
}
