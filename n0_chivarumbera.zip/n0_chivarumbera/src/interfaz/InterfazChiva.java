package interfaz;

import mundo.Chiva;
public class InterfazChiva {

	public static void main(String[] args) 
	{
		Chiva chiva1;
		
		chiva1 = new Chiva( "Breyner Florez", 20, 15, 2000);
		
		System.out.println( chiva1.getNombre( ) );
		System.out.println( chiva1.getCapacidad( ) );
		System.out.println( chiva1.getCantidadSillas( ) );
		System.out.println( chiva1.getPrecioHora( ) );
	}

}
